import { Itinerary, Segment } from '@/types';

export interface ChatResult {
  response: string;
  updatedItineraries?: Itinerary[];
  highlightId?: string;
}

const LOW_COST_CARRIERS = ['easyJet', 'Transavia', 'Ryanair', 'Vueling', 'Wizz Air'];

function isLowCost(segment: Segment): boolean {
  return LOW_COST_CARRIERS.some((c) => segment.carrier.toLowerCase().includes(c.toLowerCase()));
}

export function processChatMessage(
  message: string,
  itineraries: Itinerary[],
): ChatResult {
  const msg = message.toLowerCase().trim();

  // ─── Remove low-cost flights ───
  if ((msg.includes('low-cost') || msg.includes('low cost') || msg.includes('lowcost')) && (msg.includes('enlève') || msg.includes('enleve') || msg.includes('retire') || msg.includes('supprime') || msg.includes('sans') || msg.includes('pas de'))) {
    const filtered = itineraries.map((it) => ({
      ...it,
      segments: it.segments.filter((s) => !(s.mode === 'flight' && isLowCost(s))),
    })).filter((it) => it.segments.length > 0 && it.segments.every((s, i) => i === 0 || it.segments[i - 1].toCity.id === s.fromCity.id));

    // Recalc prices for valid ones; drop broken chains
    const valid = filtered.filter((it) => {
      const connected = it.segments.every((s, i) => i === 0 || it.segments[i - 1].toCity.id === s.fromCity.id);
      return connected && it.segments.length > 0;
    }).map((it) => ({
      ...it,
      totalPrice: it.segments.reduce((a, s) => a + s.price, 0) + (it.stopover?.estimatedLodgingCost ?? 0),
      tags: it.tags.map((t) => t === 'Bus + Vol + Bus' ? 'Bus + Vol' : t),
    }));

    if (valid.length === 0) {
      return {
        response: "J'ai retiré les vols low-cost, mais malheureusement il ne reste plus aucun itinéraire viable sans eux sur ce trajet. Voulez-vous que je les réintègre ?",
        updatedItineraries: itineraries,
      };
    }

    return {
      response: `C'est fait ! J'ai retiré les compagnies low-cost (${LOW_COST_CARRIERS.slice(0, 3).join(', ')}…). Il reste ${valid.length} itinéraire${valid.length > 1 ? 's' : ''} avec des transporteurs classiques comme Air France, Austrian Airlines ou TGV inOui. Le tableau de bord est mis à jour.`,
      updatedItineraries: valid,
    };
  }

  // ─── Night train ───
  if ((msg.includes('train de nuit') || msg.includes('train de_nuit') || (msg.includes('train') && msg.includes('nuit')))) {
    const withTrains = itineraries.filter((it) => it.segments.some((s) => s.mode === 'train'));
    if (withTrains.length === 0) {
      return {
        response: "Aucun train de nuit direct n'est disponible sur ce trajet pour le moment. Cependant, l'option via Vienne inclut un trajet en train ÖBB Railjet — c'est l'approche la plus proche d'un voyage ferroviaire confortable. Voulez-vous que je priorise cette option ?",
        updatedItineraries: itineraries,
        highlightId: 'itin-smart-vienna',
      };
    }
    return {
      response: "Bonne idée ! J'ai repéré des options avec train. L'itinéraire via Vienne combine TGV + vol + train ÖBB Railjet — un compromis confortable et écologique. Je le mets en avant dans le tableau de bord.",
      updatedItineraries: itineraries,
      highlightId: 'itin-smart-vienna',
    };
  }

  // ─── Add a day to Berlin stopover ───
  if ((msg.includes('ajoute') || msg.includes('rajoute') || msg.includes('plus') || msg.includes('extended') || msg.includes('prolonge')) && (msg.includes('berlin') || msg.includes('escale')) && (msg.includes('jour') || msg.includes('escale'))) {
    const updated = itineraries.map((it) => {
      if (it.id === 'itin-smart-berlin' && it.stopover) {
        const newDays = Math.min(it.stopover.days + 1, 3);
        const newLodging = it.stopover.estimatedLodgingCost + 30;
        return {
          ...it,
          stopover: { ...it.stopover, days: newDays, estimatedLodgingCost: newLodging },
          totalPrice: it.totalPrice + 30,
          totalDurationMinutes: it.totalDurationMinutes + 24 * 60,
          tags: it.tags.map((t) => t.includes('jours à Berlin') ? `${newDays} jours à Berlin` : t),
        };
      }
      return it;
    });
    const berlin = updated.find((i) => i.id === 'itin-smart-berlin');
    return {
      response: berlin?.stopover
        ? `Excellent choix ! J'ai prolongé votre escale à Berlin : ${berlin.stopover.days} jours maintenant. Comptez ~30€ de plus pour l'hébergement (auberge de jeunesse). Cela vous laisse le temps de visiter le Mur de Berlin, la Porte de Brandebourg, Museum Island et même Potsdam. Le tableau de bord est actualisé.`
        : "Je n'ai pas trouvé d'escale à Berlin dans les itinéraires actuels.",
      updatedItineraries: updated,
      highlightId: 'itin-smart-berlin',
    };
  }

  // ─── Cheapest / budget ───
  if ((msg.includes('moins cher') || msg.includes('le moins cher') || msg.includes('budget') || msg.includes('pas cher') || msg.includes('économ') || msg.includes('eco'))) {
    const cheapest = [...itineraries].sort((a, b) => a.totalPrice - b.totalPrice)[0];
    return {
      response: `L'option la plus économique est à ${cheapest.totalPrice}€ : ${cheapest.tags.join(', ')}. C'est un trajet multimodal combinant bus et vol. Je l'ai mise en avant dans le tableau de bord.`,
      updatedItineraries: itineraries,
      highlightId: cheapest.id,
    };
  }

  // ─── Fastest ───
  if ((msg.includes('rapide') || msg.includes('vite') || msg.includes('direct') || msg.includes('court'))) {
    const fastest = [...itineraries].sort((a, b) => a.totalDurationMinutes - b.totalDurationMinutes)[0];
    return {
      response: `L'option la plus rapide prend seulement ${Math.round(fastest.totalDurationMinutes / 60)}h : ${fastest.tags.join(', ')}. C'est un combo TGV + vol via Paris. Je l'ai mise en avant dans le tableau de bord.`,
      updatedItineraries: itineraries,
      highlightId: fastest.id,
    };
  }

  // ─── Berlin / stopover explanation ───
  if (msg.includes('berlin') || msg.includes('escale') || msg.includes('stopover') || msg.includes('pourquoi')) {
    const berlin = itineraries.find((i) => i.id === 'itin-smart-berlin');
    if (berlin) {
      return {
        response: `L'escale à Berlin est notre pépite ! Voici pourquoi : un vol direct Nantes→Prague coûte environ 270€. En passant 2 jours à Berlin, le trajet vous revient à ${berlin.totalPrice}€ (vol easyJet NTE→BER à 72€ + 2 nuits d'auberge à 60€ + bus Berlin→Prague à 19€). Soit une économie de ${270 - berlin.totalPrice}€ ! Et en bonus, vous découvrez une des villes les plus fascinantes d'Europe. C'est ça, voyager malin.`,
        updatedItineraries: itineraries,
        highlightId: 'itin-smart-berlin',
      };
    }
  }

  // ─── Train only ───
  if ((msg.includes('que') || msg.includes('seulement') || msg.includes('uniquement')) && msg.includes('train')) {
    const trainOnly = itineraries.filter((it) => it.segments.every((s) => s.mode === 'train'));
    if (trainOnly.length === 0) {
      return {
        response: "Il n'y a pas d'itinéraire 100% train sur Nantes→Prague avec les données actuelles. Le trajet ferroviaire complet nécessiterait 3 à 4 correspondances (TGV → ICE →Regional). Voulez-vous que je priorise les options avec le plus de train possible ?",
        updatedItineraries: itineraries,
      };
    }
    return { response: `J'ai filtré pour ne garder que les trajets en train. ${trainOnly.length} option(s) disponible(s).`, updatedItineraries: trainOnly };
  }

  // ─── Bus only ───
  if ((msg.includes('que') || msg.includes('seulement') || msg.includes('uniquement')) && msg.includes('bus')) {
    return {
      response: "Un trajet Nantes→Prague en bus uniquement (FlixBus) existerait mais prendrait environ 18-20h avec correspondances. Ce n'est pas dans le jeu de données actuel, mais je peux l'ajouter si vous le souhaitez !",
      updatedItineraries: itineraries,
    };
  }

  // ─── Greetings ───
  if (msg.match(/^(salut|bonjour|hello|hey|coucou|bonsoir)/)) {
    return {
      response: "Bonjour ! Je suis votre assistant voyage. Posez-moi vos questions ou dites-moi ce que vous souhaitez ajuster : « Enlève les vols low-cost », « Propose un train de nuit », « Ajoute un jour d'escale à Berlin »… Je modifierai les options en temps réel à droite.",
    };
  }

  // ─── Help ───
  if (msg.includes('aide') || msg.includes('help') || msg.includes('comment')) {
    return {
      response: "Je peux vous aider à affiner votre recherche ! Essayez :\n• « Enlève les vols low-cost »\n• « Propose un train de nuit »\n• « Ajoute un jour d'escale à Berlin »\n• « Quel est le trajet le moins cher ? »\n• « Pourquoi l'escale à Berlin ? »",
    };
  }

  // ─── Default ───
  return {
    response: "Je n'ai pas tout saisi, mais je peux vous aider avec : filtrer les compagnies (« Enlève les low-cost »), prioriser un mode de transport (« Propose un train de nuit »), ajuster les escales (« Ajoute un jour à Berlin »), ou comparer les options (« Quel est le moins cher ? »). Que souhaitez-vous ?",
  };
}

export const INITIAL_CHAT_MESSAGES = [
  {
    role: 'assistant' as const,
    content: "Bonjour ! Je suis TripMorph AI, votre assistant de voyage multimodal. 👋\n\nJe vois que vous cherchez un trajet Nantes → Prague. J'ai déjà analysé plusieurs options et je voulais vous parler de la pépite que j'ai trouvée…",
  },
  {
    role: 'assistant' as const,
    content: "L'escale à Berlin est notre meilleure découverte ! Un vol direct Nantes→Prague coûte environ 270€. Mais en passant 2 jours à Berlin, le voyage complet vous revient à seulement 151€ — soit une économie de 120€ !\n\nVous prenez un vol easyJet Nantes→Berlin (72€), profitez de 2 jours pour explorer la Porte de Brandebourg et le Mur de Berlin (~60€ d'auberge), puis un bus FlixBus Berlin→Prague (19€). Le voyage est plus long, mais vous transformez une simple correspondance en mini-aventure touristique tout en économisant.\n\nDites-moi ce que vous souhaitez ajuster — je peux filtrer les compagnies, ajouter des jours d'escale, ou chercher des alternatives en train !",
  },
];
