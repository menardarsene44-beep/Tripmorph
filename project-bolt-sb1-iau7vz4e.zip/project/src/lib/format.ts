import { TransportMode } from '@/types';

export function formatDuration(minutes: number): string {
  const days = Math.floor(minutes / (60 * 24));
  const hours = Math.floor((minutes % (60 * 24)) / 60);
  const mins = minutes % 60;
  const parts: string[] = [];
  if (days > 0) parts.push(`${days}j`);
  if (hours > 0) parts.push(`${hours}h`);
  if (mins > 0 && days === 0) parts.push(`${mins}min`);
  return parts.join(' ') || '0min';
}

export function formatPrice(price: number, currency: string): string {
  return new Intl.NumberFormat('fr-FR', { style: 'currency', currency }).format(price);
}

export function formatTime(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
}

export function formatDate(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleDateString('fr-FR', { weekday: 'short', day: 'numeric', month: 'short' });
}

export const MODE_META: Record<TransportMode, { label: string; icon: string; color: string }> = {
  flight: { label: 'Avion', icon: 'Plane', color: 'bg-sky-100 text-sky-700' },
  train: { label: 'Train', icon: 'TrainFront', color: 'bg-emerald-100 text-emerald-700' },
  bus: { label: 'Bus', icon: 'Bus', color: 'bg-amber-100 text-amber-700' },
};
