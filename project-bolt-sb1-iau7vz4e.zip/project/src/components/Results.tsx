import { useState, useEffect } from 'react';
import { Zap, Euro, Gem, Inbox } from 'lucide-react';
import { Itinerary, ItineraryType } from '@/types';
import ItineraryCard from './ItineraryCard';

interface Props {
  itineraries: Itinerary[];
  loading: boolean;
  highlightId?: string;
}

type TabId = ItineraryType | 'all';

const TABS: { id: TabId; label: string; icon: typeof Zap }[] = [
  { id: 'fastest', label: 'Le plus rapide', icon: Zap },
  { id: 'cheapest', label: 'Le moins cher', icon: Euro },
  { id: 'smart_stopover', label: 'Pépite Éscale', icon: Gem },
];

export default function Results({ itineraries, loading, highlightId }: Props) {
  const [tab, setTab] = useState<TabId>('all');

  useEffect(() => {
    if (highlightId) {
      const it = itineraries.find((i) => i.id === highlightId);
      if (it) setTab(it.type);
    }
  }, [highlightId, itineraries]);

  if (loading) {
    return (
      <div className="space-y-4">
        {[0, 1].map((i) => (
          <div key={i} className="rounded-2xl border border-slate-100 overflow-hidden">
            <div className="h-12 animate-shimmer" />
            <div className="p-5 space-y-3">
              <div className="h-5 w-2/3 rounded animate-shimmer" />
              <div className="h-4 w-1/2 rounded animate-shimmer" />
              <div className="grid grid-cols-3 gap-3 mt-4">
                <div className="h-16 rounded-xl animate-shimmer" />
                <div className="h-16 rounded-xl animate-shimmer" />
                <div className="h-16 rounded-xl animate-shimmer" />
              </div>
              <div className="h-10 rounded-xl animate-shimmer" />
            </div>
          </div>
        ))}
      </div>
    );
  }

  const filtered = tab === 'all' ? itineraries : itineraries.filter((i) => i.type === tab);
  const tabCounts = (id: TabId) =>
    id === 'all' ? itineraries.length : itineraries.filter((i) => i.type === id).length;

  return (
    <div>
      {/* Tabs */}
      <div className="sticky top-4 z-30 mb-5">
        <div className="flex gap-1.5 p-1.5 bg-white rounded-2xl shadow-md shadow-slate-200/40 border border-slate-100 overflow-x-auto scrollbar-hide">
          {TABS.map((t) => {
            const Icon = t.icon;
            const active = tab === t.id;
            const count = tabCounts(t.id);
            return (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`relative flex items-center gap-2 px-3.5 py-2.5 rounded-xl text-sm font-bold whitespace-nowrap transition-all ${
                  active
                    ? t.id === 'fastest'
                      ? 'bg-sky-500 text-white shadow-md shadow-sky-500/30'
                      : t.id === 'cheapest'
                        ? 'bg-emerald-500 text-white shadow-md shadow-emerald-500/30'
                        : 'bg-violet-500 text-white shadow-md shadow-violet-500/30'
                    : 'text-slate-500 hover:bg-slate-50'
                }`}
              >
                <Icon className="w-4 h-4" />
                {t.label}
                <span className={`px-1.5 py-0.5 rounded-md text-[10px] font-extrabold ${active ? 'bg-white/20' : 'bg-slate-100 text-slate-400'}`}>
                  {count}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Cards */}
      {filtered.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 text-center">
          <div className="w-16 h-16 rounded-2xl bg-slate-100 flex items-center justify-center mb-4">
            <Inbox className="w-8 h-8 text-slate-300" />
          </div>
          <h3 className="text-lg font-bold text-slate-700">Aucun itinéraire dans cette catégorie</h3>
          <p className="text-sm text-slate-400 mt-1">Essayez un autre onglet ou demandez à l'IA d'ajuster.</p>
        </div>
      ) : (
        <div className="grid gap-4 xl:grid-cols-2">
          {filtered.map((it, i) => (
            <div
              key={it.id}
              className={`transition-all duration-500 rounded-2xl ${
                highlightId === it.id
                  ? 'ring-2 ring-sky-400 ring-offset-2 scale-[1.02]'
                  : ''
              }`}
            >
              <ItineraryCard itinerary={it} index={i} />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
