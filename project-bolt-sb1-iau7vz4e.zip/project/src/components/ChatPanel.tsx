import { useState, useRef, useEffect } from 'react';
import { Sparkles, Send, Bot, User, Loader2, Lightbulb } from 'lucide-react';
import { Itinerary } from '@/types';
import { processChatMessage, INITIAL_CHAT_MESSAGES } from '@/lib/chatProcessor';

interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

interface Props {
  itineraries: Itinerary[];
  onItinerariesUpdate: (itineraries: Itinerary[]) => void;
  onHighlight: (id: string | undefined) => void;
}

const QUICK_PROMPTS = [
  'Enlève les vols low-cost',
  'Propose un train de nuit',
  'Ajoute un jour d\'escale à Berlin',
  'Quel est le moins cher ?',
];

export default function ChatPanel({ itineraries, onItinerariesUpdate, onHighlight }: Props) {
  const [messages, setMessages] = useState<ChatMessage[]>(INITIAL_CHAT_MESSAGES);
  const [input, setInput] = useState('');
  const [thinking, setThinking] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, thinking]);

  function send(text: string) {
    const trimmed = text.trim();
    if (!trimmed || thinking) return;

    const userMsg: ChatMessage = { role: 'user', content: trimmed };
    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setThinking(true);

    setTimeout(() => {
      const result = processChatMessage(trimmed, itineraries);
      const assistantMsg: ChatMessage = { role: 'assistant', content: result.response };
      setMessages((prev) => [...prev, assistantMsg]);
      if (result.updatedItineraries) {
        onItinerariesUpdate(result.updatedItineraries);
      }
      if (result.highlightId) {
        onHighlight(result.highlightId);
        setTimeout(() => onHighlight(undefined), 3000);
      }
      setThinking(false);
    }, 700 + Math.random() * 400);
  }

  return (
    <div className="flex flex-col h-full bg-white rounded-2xl border border-slate-100 shadow-lg shadow-slate-200/40 overflow-hidden">
      {/* Header */}
      <div className="flex items-center gap-3 px-4 py-3.5 bg-gradient-to-r from-sky-500 to-blue-600 text-white">
        <div className="w-9 h-9 rounded-xl bg-white/20 backdrop-blur flex items-center justify-center shrink-0">
          <Bot className="w-5 h-5" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="text-sm font-extrabold leading-none">TripMorph AI</div>
          <div className="text-[11px] text-sky-100 mt-0.5 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-300 animate-pulse" />
            En ligne · Affine votre recherche
          </div>
        </div>
        <Sparkles className="w-4 h-4 text-sky-200" />
      </div>

      {/* Messages */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 py-4 space-y-3 scrollbar-hide">
        {messages.map((msg, i) => (
          <MessageBubble key={i} message={msg} />
        ))}
        {thinking && (
          <div className="flex items-start gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-sky-500 to-blue-600 flex items-center justify-center shrink-0">
              <Loader2 className="w-3.5 h-3.5 text-white animate-spin" />
            </div>
            <div className="flex items-center gap-1 px-3.5 py-3 rounded-2xl rounded-tl-sm bg-slate-100">
              <span className="w-1.5 h-1.5 rounded-full bg-slate-400 animate-bounce" style={{ animationDelay: '0ms' }} />
              <span className="w-1.5 h-1.5 rounded-full bg-slate-400 animate-bounce" style={{ animationDelay: '150ms' }} />
              <span className="w-1.5 h-1.5 rounded-full bg-slate-400 animate-bounce" style={{ animationDelay: '300ms' }} />
            </div>
          </div>
        )}
      </div>

      {/* Quick prompts */}
      <div className="px-3 pb-2 flex gap-1.5 flex-wrap">
        {QUICK_PROMPTS.map((p) => (
          <button
            key={p}
            onClick={() => send(p)}
            disabled={thinking}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-50 hover:bg-sky-50 text-slate-500 hover:text-sky-600 text-xs font-medium border border-slate-100 hover:border-sky-200 transition disabled:opacity-50"
          >
            <Lightbulb className="w-3 h-3" />
            {p}
          </button>
        ))}
      </div>

      {/* Input */}
      <div className="p-3 border-t border-slate-100">
        <div className="flex items-center gap-2">
          <input
            ref={inputRef}
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter') send(input); }}
            placeholder="Demandez à l'IA d'ajuster…"
            className="flex-1 px-3.5 py-2.5 rounded-xl border border-slate-200 bg-slate-50 text-sm text-slate-700 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-sky-400/50 focus:border-sky-400 focus:bg-white transition"
          />
          <button
            onClick={() => send(input)}
            disabled={thinking || !input.trim()}
            className="w-10 h-10 rounded-xl bg-gradient-to-br from-sky-500 to-blue-600 text-white flex items-center justify-center shadow-md shadow-sky-500/30 hover:shadow-lg hover:shadow-sky-500/40 active:scale-95 transition disabled:opacity-40 disabled:cursor-not-allowed shrink-0"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}

function MessageBubble({ message }: { message: ChatMessage }) {
  const isUser = message.role === 'user';
  return (
    <div className={`flex items-start gap-2.5 ${isUser ? 'flex-row-reverse' : ''}`}>
      <div className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${
        isUser ? 'bg-slate-200' : 'bg-gradient-to-br from-sky-500 to-blue-600'
      }`}>
        {isUser ? <User className="w-3.5 h-3.5 text-slate-500" /> : <Bot className="w-3.5 h-3.5 text-white" />}
      </div>
      <div className={`max-w-[85%] px-3.5 py-2.5 rounded-2xl text-sm leading-relaxed whitespace-pre-line ${
        isUser
          ? 'bg-slate-800 text-white rounded-tr-sm'
          : 'bg-slate-100 text-slate-700 rounded-tl-sm'
      }`}>
        {message.content}
      </div>
    </div>
  );
}
