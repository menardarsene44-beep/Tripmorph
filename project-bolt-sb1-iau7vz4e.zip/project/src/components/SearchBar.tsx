import { ArrowRightLeft, Calendar, Zap, Scale, Leaf, Search, Loader2, Building2 } from 'lucide-react';
import { useState } from 'react';
import CityAutocomplete from './CityAutocomplete';
import { City, TravelMode } from '@/types';
import { CITIES } from '@/data/cities';

interface Props {
  onSearch: (params: {
    fromCity: City;
    toCity: City;
    departDate: string;
    returnDate: string;
    oneWay: boolean;
    travelMode: TravelMode;
    allowStopovers: boolean;
  }) => void;
  loading: boolean;
}

const MODES: { id: TravelMode; label: string; icon: typeof Zap; desc: string }[] = [
  { id: 'ultra_fast', label: 'Ultra Rapide', icon: Zap, desc: 'Trajet le plus court' },
  { id: 'optimal', label: 'Compromis Optimal', icon: Scale, desc: 'Équilibré prix/temps' },
  { id: 'ultra_eco', label: 'Ultra Éco', icon: Leaf, desc: 'Le moins cher' },
];

export default function SearchBar({ onSearch, loading }: Props) {
  const [fromCity, setFromCity] = useState<City>(CITIES[0]);
  const [toCity, setToCity] = useState<City>(CITIES.find((c) => c.id === 'prague')!);
  const [departDate, setDepartDate] = useState('2026-07-04');
  const [returnDate, setReturnDate] = useState('2026-07-11');
  const [oneWay, setOneWay] = useState(false);
  const [travelMode, setTravelMode] = useState<TravelMode>('optimal');
  const [allowStopovers, setAllowStopovers] = useState(true);

  function swap() {
    setFromCity(toCity);
    setToCity(fromCity);
  }

  function handleSubmit() {
    onSearch({ fromCity, toCity, departDate, returnDate, oneWay, travelMode, allowStopovers });
  }

  return (
    <div className="bg-white rounded-3xl shadow-2xl shadow-slate-300/40 border border-slate-100 p-5 sm:p-7">
      {/* Row 1: Cities + Dates */}
      <div className="flex flex-col lg:flex-row gap-4">
        {/* From */}
        <div className="flex-1 relative">
          <CityAutocomplete label="Ville de départ" value={fromCity} onSelect={setFromCity} excludeId={toCity?.id} placeholder="D'où partez-vous ?" />
        </div>

        {/* Swap */}
        <div className="flex items-end pb-1">
          <button
            onClick={swap}
            className="w-10 h-10 rounded-full border border-slate-200 bg-white text-slate-400 hover:text-sky-500 hover:border-sky-300 hover:bg-sky-50 transition flex items-center justify-center"
            aria-label="Inverser"
          >
            <ArrowRightLeft className="w-4 h-4" />
          </button>
        </div>

        {/* To */}
        <div className="flex-1 relative">
          <CityAutocomplete label="Ville d'arrivée" value={toCity} onSelect={setToCity} excludeId={fromCity?.id} placeholder="Où allez-vous ?" />
        </div>

        {/* Dates */}
        <div className="flex gap-3 flex-1">
          <div className="flex-1">
            <label className="block text-xs font-semibold uppercase tracking-wide text-slate-400 mb-1">Départ</label>
            <div className="relative">
              <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
              <input
                type="date"
                value={departDate}
                onChange={(e) => setDepartDate(e.target.value)}
                className="w-full pl-10 pr-2 py-3 rounded-xl border border-slate-200 bg-white text-sm font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-400/50 focus:border-sky-400 transition"
              />
            </div>
          </div>
          {!oneWay && (
            <div className="flex-1">
              <label className="block text-xs font-semibold uppercase tracking-wide text-slate-400 mb-1">Retour</label>
              <div className="relative">
                <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
                <input
                  type="date"
                  value={returnDate}
                  onChange={(e) => setReturnDate(e.target.value)}
                  className="w-full pl-10 pr-2 py-3 rounded-xl border border-slate-200 bg-white text-sm font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-400/50 focus:border-sky-400 transition"
                />
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Row 2: One-way toggle */}
      <div className="mt-4 flex items-center gap-3">
        <label className="flex items-center gap-2 cursor-pointer select-none">
          <button
            type="button"
            onClick={() => setOneWay(!oneWay)}
            className={`relative w-11 h-6 rounded-full transition ${oneWay ? 'bg-sky-500' : 'bg-slate-200'}`}
          >
            <span className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform ${oneWay ? 'translate-x-5' : ''}`} />
          </button>
          <span className="text-sm font-medium text-slate-600">Aller simple</span>
        </label>
      </div>

      {/* Row 3: Travel mode toggle */}
      <div className="mt-5">
        <label className="block text-xs font-semibold uppercase tracking-wide text-slate-400 mb-2">
          Rapport Temps / Prix
        </label>
        <div className="grid grid-cols-3 gap-2 sm:gap-3">
          {MODES.map((m) => {
            const Icon = m.icon;
            const active = travelMode === m.id;
            return (
              <button
                key={m.id}
                onClick={() => setTravelMode(m.id)}
                className={`relative flex flex-col items-center gap-1 py-3 px-2 rounded-xl border-2 transition-all ${
                  active
                    ? 'border-sky-500 bg-sky-50 text-sky-700 shadow-sm'
                    : 'border-slate-100 bg-white text-slate-500 hover:border-slate-200 hover:bg-slate-50'
                }`}
              >
                <Icon className={`w-5 h-5 ${active ? 'text-sky-600' : 'text-slate-400'}`} />
                <span className="text-xs sm:text-sm font-bold">{m.label}</span>
                <span className="hidden sm:block text-[10px] text-slate-400">{m.desc}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Row 4: Stopover checkbox + Search */}
      <div className="mt-5 flex flex-col sm:flex-row items-stretch sm:items-center gap-4 justify-between">
        <label className="flex items-start gap-3 cursor-pointer select-none group">
          <button
            type="button"
            onClick={() => setAllowStopovers(!allowStopovers)}
            className={`mt-0.5 relative w-11 h-6 rounded-full transition shrink-0 ${allowStopovers ? 'bg-emerald-500' : 'bg-slate-200'}`}
          >
            <span className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform ${allowStopovers ? 'translate-x-5' : ''}`} />
          </button>
          <span className="text-sm font-medium text-slate-700 leading-snug">
            <span className="flex items-center gap-1.5">
              <Building2 className="w-3.5 h-3.5 text-emerald-500" />
              Autoriser les escales touristiques
            </span>
            <span className="text-xs text-slate-400">Visitez une ville étape 1 à 3 jours si cela réduit le prix global</span>
          </span>
        </label>

        <button
          onClick={handleSubmit}
          disabled={loading}
          className="flex items-center justify-center gap-2 px-8 py-3.5 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 text-white font-bold text-sm shadow-lg shadow-sky-500/30 hover:shadow-xl hover:shadow-sky-500/40 hover:from-sky-600 hover:to-blue-700 active:scale-[0.98] transition-all disabled:opacity-60 disabled:cursor-not-allowed whitespace-nowrap"
        >
          {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Search className="w-5 h-5" />}
          {loading ? 'Recherche…' : 'Comparer les trajets'}
        </button>
      </div>
    </div>
  );
}
