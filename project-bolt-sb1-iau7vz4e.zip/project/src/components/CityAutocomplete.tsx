import { useState, useRef, useEffect } from 'react';
import { MapPin, X, Search } from 'lucide-react';
import { CITIES } from '@/data/cities';
import { City } from '@/types';

interface Props {
  label: string;
  value: City | null;
  onSelect: (city: City) => void;
  placeholder?: string;
  excludeId?: string;
}

export default function CityAutocomplete({ label, value, onSelect, placeholder, excludeId }: Props) {
  const [query, setQuery] = useState('');
  const [open, setOpen] = useState(false);
  const [filtered, setFiltered] = useState<City[]>([]);
  const ref = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    function handleClick(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
        setQuery('');
      }
    }
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  useEffect(() => {
    if (query.length < 1) {
      setFiltered(CITIES.filter((c) => c.id !== excludeId).slice(0, 8));
      return;
    }
    const q = query.toLowerCase();
    setFiltered(
      CITIES.filter(
        (c) =>
          c.id !== excludeId &&
          (c.name.toLowerCase().includes(q) ||
            c.country.toLowerCase().includes(q) ||
            (c.iata ?? '').toLowerCase().includes(q)),
      ).slice(0, 8),
    );
  }, [query, excludeId]);

  function handleSelect(city: City) {
    onSelect(city);
    setOpen(false);
    setQuery('');
    inputRef.current?.blur();
  }

  return (
    <div ref={ref} className="relative w-full">
      <label className="block text-xs font-semibold uppercase tracking-wide text-slate-400 mb-1">{label}</label>
      <div className="relative">
        <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
        <input
          ref={inputRef}
          type="text"
          value={open ? query : value?.name ?? ''}
          placeholder={placeholder ?? 'Ville ou aéroport'}
          onChange={(e) => {
            setQuery(e.target.value);
            setOpen(true);
          }}
          onFocus={() => setOpen(true)}
          className="w-full pl-10 pr-8 py-3 rounded-xl border border-slate-200 bg-white text-sm font-medium text-slate-800 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-sky-400/50 focus:border-sky-400 transition"
        />
        {value && !open && (
          <button
            onClick={() => {
              setOpen(true);
              inputRef.current?.focus();
            }}
            className="absolute right-2 top-1/2 -translate-y-1/2 p-1 rounded-lg text-slate-300 hover:text-slate-600 hover:bg-slate-100 transition"
          >
            <Search className="w-4 h-4" />
          </button>
        )}
        {open && query && (
          <button
            onClick={() => {
              setQuery('');
              inputRef.current?.focus();
            }}
            className="absolute right-2 top-1/2 -translate-y-1/2 p-1 rounded-lg text-slate-300 hover:text-slate-600 hover:bg-slate-100 transition"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>
      {open && (
        <div className="absolute z-50 mt-2 w-full bg-white rounded-xl border border-slate-200 shadow-xl shadow-slate-200/60 max-h-64 overflow-y-auto scrollbar-hide">
          {filtered.length === 0 && (
            <div className="px-4 py-3 text-sm text-slate-400">Aucune ville trouvée</div>
          )}
          {filtered.map((city) => (
            <button
              key={city.id}
              onClick={() => handleSelect(city)}
              className="w-full flex items-center gap-3 px-4 py-2.5 text-left hover:bg-sky-50 transition group"
            >
              <div className="w-8 h-8 rounded-lg bg-slate-100 group-hover:bg-sky-100 flex items-center justify-center text-xs font-bold text-slate-500 group-hover:text-sky-600 transition">
                {city.iata ?? city.country_code}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-semibold text-slate-800">{city.name}</div>
                <div className="text-xs text-slate-400">{city.country}</div>
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
