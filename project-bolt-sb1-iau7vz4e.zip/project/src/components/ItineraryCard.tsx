import { useState } from 'react';
import {
  Plane, TrainFront, Bus, Clock, Euro, ChevronDown, MapPin,
  ArrowRight, ExternalLink, Building2, TrendingDown, Calendar,
} from 'lucide-react';
import { Itinerary, Segment, TransportMode } from '@/types';
import { formatDuration, formatPrice, formatTime, formatDate } from '@/lib/format';

const MODE_ICON: Record<TransportMode, typeof Plane> = {
  flight: Plane,
  train: TrainFront,
  bus: Bus,
};

const MODE_COLOR: Record<TransportMode, string> = {
  flight: 'bg-sky-500',
  train: 'bg-emerald-500',
  bus: 'bg-amber-500',
};

const TYPE_LABEL: Record<string, string> = {
  fastest: 'Le plus rapide',
  cheapest: 'Le moins cher',
  smart_stopover: 'Pépite Éscale',
};

interface Props {
  itinerary: Itinerary;
  index: number;
}

export default function ItineraryCard({ itinerary, index }: Props) {
  const [expanded, setExpanded] = useState(false);

  const transportDuration = itinerary.segments.reduce((a, s) => a + s.durationMinutes, 0);
  const stopoverDuration = itinerary.stopover ? itinerary.stopover.days * 24 * 60 : 0;

  return (
    <div
      className="animate-fade-up bg-white rounded-2xl border border-slate-100 shadow-lg shadow-slate-200/40 overflow-hidden hover:shadow-xl hover:shadow-slate-300/40 transition-shadow"
      style={{ animationDelay: `${index * 80}ms` }}
    >
      {/* Header band */}
      <div className="flex items-center justify-between px-5 py-3 bg-gradient-to-r from-slate-50 to-white border-b border-slate-100">
        <div className="flex items-center gap-2">
          {itinerary.segments.map((s, i) => {
            const Icon = MODE_ICON[s.mode];
            return (
              <span key={i} className="flex items-center">
                <span className={`w-7 h-7 rounded-lg ${MODE_COLOR[s.mode]} text-white flex items-center justify-center`}>
                  <Icon className="w-3.5 h-3.5" />
                </span>
                {i < itinerary.segments.length - 1 && (
                  <ArrowRight className="w-3 h-3 text-slate-300 mx-0.5" />
                )}
              </span>
            );
          })}
          <span className="ml-2 text-xs font-bold text-slate-500 uppercase tracking-wide">
            {TYPE_LABEL[itinerary.type]}
          </span>
        </div>
        {itinerary.savingsPercent > 0 && (
          <span className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-700 text-xs font-bold">
            <TrendingDown className="w-3.5 h-3.5" />
            -{itinerary.savingsPercent}% vs direct
          </span>
        )}
      </div>

      {/* Body */}
      <div className="px-5 py-4">
        {/* Route summary */}
        <div className="flex items-center gap-2 mb-3">
          {itinerary.segments.map((s, i) => (
            <span key={i} className="flex items-center text-sm font-bold text-slate-700">
              {i === 0 && <span>{s.fromCity.name}</span>}
              <ArrowRight className="w-3.5 h-3.5 text-slate-300 mx-1.5" />
              <span>{s.toCity.name}</span>
              {i < itinerary.segments.length - 1 && <span className="text-slate-300 mx-1">·</span>}
            </span>
          ))}
        </div>

        {/* Tags */}
        <div className="flex flex-wrap gap-1.5 mb-4">
          {itinerary.tags.map((tag) => (
            <span key={tag} className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-500 text-xs font-medium">
              {tag}
            </span>
          ))}
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-3 mb-4">
          <div className="rounded-xl bg-sky-50 px-3 py-2.5">
            <div className="flex items-center gap-1 text-sky-600 text-xs font-semibold mb-0.5">
              <Euro className="w-3.5 h-3.5" /> Prix total
            </div>
            <div className="text-lg font-extrabold text-slate-800">{formatPrice(itinerary.totalPrice, itinerary.currency)}</div>
          </div>
          <div className="rounded-xl bg-violet-50 px-3 py-2.5">
            <div className="flex items-center gap-1 text-violet-600 text-xs font-semibold mb-0.5">
              <Clock className="w-3.5 h-3.5" /> Durée totale
            </div>
            <div className="text-lg font-extrabold text-slate-800">{formatDuration(itinerary.totalDurationMinutes)}</div>
          </div>
          <div className="rounded-xl bg-slate-100 px-3 py-2.5">
            <div className="flex items-center gap-1 text-slate-500 text-xs font-semibold mb-0.5">
              <MapPin className="w-3.5 h-3.5" /> Escales
            </div>
            <div className="text-lg font-extrabold text-slate-800">
              {itinerary.stopover ? `${itinerary.stopover.days}j` : '—'}
            </div>
          </div>
        </div>

        {/* Stopover highlight */}
        {itinerary.stopover && (
          <div className="mb-4 flex items-start gap-3 p-3 rounded-xl bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-100">
            <Building2 className="w-5 h-5 text-emerald-600 mt-0.5 shrink-0" />
            <div>
              <div className="text-sm font-bold text-emerald-800">
                Escale touristique : {itinerary.stopover.days} jour{itinerary.stopover.days > 1 ? 's' : ''} à {itinerary.stopover.city.name}
              </div>
              <div className="text-xs text-emerald-700 mt-0.5">{itinerary.stopover.note}</div>
              <div className="text-xs text-emerald-600 mt-1 font-medium">
                Hébergement estimé : {formatPrice(itinerary.stopover.estimatedLodgingCost, itinerary.stopover.currency)}
              </div>
            </div>
          </div>
        )}

        {/* Duration breakdown */}
        <div className="flex items-center gap-4 text-xs text-slate-400 mb-4">
          <span>Transport : {formatDuration(transportDuration)}</span>
          {stopoverDuration > 0 && <span>·</span>}
          {stopoverDuration > 0 && <span>Escale : {formatDuration(stopoverDuration)}</span>}
        </div>

        {/* Expand button */}
        <button
          onClick={() => setExpanded(!expanded)}
          className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-600 text-sm font-bold transition"
        >
          {expanded ? 'Masquer le détail' : 'Voir les billets & Réserver'}
          <ChevronDown className={`w-4 h-4 transition-transform ${expanded ? 'rotate-180' : ''}`} />
        </button>

        {/* Expanded detail */}
        {expanded && (
          <div className="mt-4 space-y-3">
            {itinerary.segments.map((seg, i) => (
              <SegmentDetail key={seg.id} segment={seg} index={i} />
            ))}
            {itinerary.stopover && (
              <div className="flex items-center gap-3 p-3 rounded-xl bg-amber-50 border border-amber-100">
                <Calendar className="w-5 h-5 text-amber-600 shrink-0" />
                <div className="text-sm">
                  <span className="font-bold text-amber-800">
                    {itinerary.stopover.days} jour{itinerary.stopover.days > 1 ? 's' : ''} à {itinerary.stopover.city.name}
                  </span>
                  <span className="text-amber-600"> — profitez de votre escale touristique</span>
                </div>
              </div>
            )}
            <div className="flex items-center justify-between pt-3 border-t border-slate-100">
              <span className="text-sm text-slate-500">Total estimé</span>
              <span className="text-xl font-extrabold text-slate-800">
                {formatPrice(itinerary.totalPrice, itinerary.currency)}
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function SegmentDetail({ segment, index }: { segment: Segment; index: number }) {
  const Icon = MODE_ICON[segment.mode];
  return (
    <div className="flex gap-3">
      {/* timeline dot + line */}
      <div className="flex flex-col items-center pt-1">
        <span className={`w-8 h-8 rounded-full ${MODE_COLOR[segment.mode]} text-white flex items-center justify-center shrink-0`}>
          <Icon className="w-4 h-4" />
        </span>
        {index < 100 && <span className="w-0.5 flex-1 bg-slate-100 mt-1" />}
      </div>

      <div className="flex-1 pb-3">
        <div className="flex items-center gap-2 mb-1">
          <span className="text-sm font-bold text-slate-800">{segment.fromCity.name}</span>
          <ArrowRight className="w-3.5 h-3.5 text-slate-300" />
          <span className="text-sm font-bold text-slate-800">{segment.toCity.name}</span>
          <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-400 text-[10px] font-bold uppercase">
            {segment.mode === 'flight' ? 'Avion' : segment.mode === 'train' ? 'Train' : 'Bus'}
          </span>
        </div>
        <div className="text-xs text-slate-500 mb-2">
          {segment.carrier} · {formatDate(segment.departureTime)} · {formatTime(segment.departureTime)} → {formatTime(segment.arrivalTime)} · {formatDuration(segment.durationMinutes)}
        </div>
        <a
          href={segment.deepLink}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-sky-50 hover:bg-sky-100 text-sky-700 text-xs font-bold transition"
        >
          Réserver ce tronçon · {formatPrice(segment.price, segment.currency)}
          <ExternalLink className="w-3 h-3" />
        </a>
      </div>
    </div>
  );
}
