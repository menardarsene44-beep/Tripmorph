export type TransportMode = 'flight' | 'train' | 'bus';

export interface City {
  id: string;
  name: string;
  country: string;
  country_code: string;
  iata?: string;
  lat: number;
  lng: number;
}

export interface Segment {
  id: string;
  fromCity: City;
  toCity: City;
  mode: TransportMode;
  carrier: string;
  carrierLogo?: string;
  price: number;
  currency: string;
  durationMinutes: number;
  departureTime: string;   // ISO
  arrivalTime: string;     // ISO
  bookingUrl: string;
  deepLink: string;        // affiliate link
}

export interface Stopover {
  city: City;
  days: number;
  note: string;
  estimatedLodgingCost: number;
  currency: string;
}

export type ItineraryType = 'fastest' | 'cheapest' | 'smart_stopover';

export interface Itinerary {
  id: string;
  type: ItineraryType;
  segments: Segment[];
  stopover?: Stopover;
  totalPrice: number;
  totalDurationMinutes: number;   // transport + stopover
  currency: string;
  savingsPercent: number;         // vs direct flight reference
  tags: string[];
}

export type TravelMode = 'ultra_fast' | 'optimal' | 'ultra_eco';
