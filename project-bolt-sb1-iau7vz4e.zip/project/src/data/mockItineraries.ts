import { Itinerary, Segment, Stopover } from '@/types';
import { City } from '@/types';

const nantes: City = { id: 'nantes', name: 'Nantes', country: 'France', country_code: 'FR', iata: 'NTE', lat: 47.2184, lng: -1.5536 };
const berlin: City = { id: 'berlin', name: 'Berlin', country: 'Allemagne', country_code: 'DE', iata: 'BER', lat: 52.3667, lng: 13.5033 };
const prague: City = { id: 'prague', name: 'Prague', country: 'République Tchèque', country_code: 'CZ', iata: 'PRG', lat: 50.1008, lng: 14.2600 };
const paris: City = { id: 'paris', name: 'Paris', country: 'France', country_code: 'FR', iata: 'CDG', lat: 49.0037, lng: 2.5711 };
const vienna: City = { id: 'vienna', name: 'Vienne', country: 'Autriche', country_code: 'AT', iata: 'VIE', lat: 48.1103, lng: 16.5697 };

const TRAVELPAYOUTS_MARKER = import.meta.env.VITE_TRAVELPAYOUTS_MARKER || '677777';

function buildAffiliateUrl(base: string): string {
  const sep = base.includes('?') ? '&' : '?';
  return `${base}${sep}marker=${TRAVELPAYOUTS_MARKER}`;
}

// All times relative to a 7-day trip departing 2026-07-04
const DEP = '2026-07-04T';

function seg(
  id: string,
  from: City,
  to: City,
  mode: Segment['mode'],
  carrier: string,
  price: number,
  durationMin: number,
  depIso: string,
  arrIso: string,
  bookingBase: string,
): Segment {
  return {
    id,
    fromCity: from,
    toCity: to,
    mode,
    carrier,
    price,
    currency: 'EUR',
    durationMinutes: durationMin,
    departureTime: depIso,
    arrivalTime: arrIso,
    bookingUrl: buildAffiliateUrl(bookingBase),
    deepLink: buildAffiliateUrl(bookingBase),
  };
}

// --- Fastest: Direct-ish flight via Paris CDG (short layover) ---
const fastestSegments: Segment[] = [
  seg('s1', nantes, paris, 'train', 'TGV inOui', 45, 125, `${DEP}06:15`, `${DEP}08:20`, 'https://www.trainline.fr/search/nantes-paris'),
  seg('s2', paris, prague, 'flight', 'Air France', 185, 140, `${DEP}10:30`, `${DEP}12:50`, 'https://www.aviasales.com/routes/CDG/PRG'),
];

// --- Cheapest: Bus + budget flight via Berlin (no overnight stay) ---
const cheapestSegments: Segment[] = [
  seg('s2-1', nantes, paris, 'bus', 'FlixBus', 22, 310, `${DEP}05:00`, `${DEP}10:10`, 'https://www.flixbus.fr/bus/nantes-paris'),
  seg('s2-2', paris, berlin, 'flight', 'Transavia', 48, 105, `${DEP}13:15`, `${DEP}15:20`, 'https://www.aviasales.com/routes/CDG/BER'),
  seg('s2-3', berlin, prague, 'bus', 'FlixBus', 15, 220, `${DEP}18:00`, `${DEP}21:40`, 'https://www.flixbus.de/bus/berlin-prague'),
];

// --- Smart Stopover: Nantes → Berlin (flight), 2-day stopover in Berlin, Berlin → Prague (bus) ---
const stopoverBerlin: Stopover = {
  city: berlin,
  days: 2,
  note: 'Explorez la Porte de Brandebourg, le Mur de Berlin et Mitte. Auberges de jeunesse dès 25€/nuit.',
  estimatedLodgingCost: 60,
  currency: 'EUR',
};

const smartStopoverSegments: Segment[] = [
  seg('s3-1', nantes, berlin, 'flight', 'easyJet', 72, 165, `${DEP}07:00`, `${DEP}09:45`, 'https://www.aviasales.com/routes/NTE/BER'),
  // 2-day stopover in Berlin
  seg('s3-2', berlin, prague, 'bus', 'FlixBus', 19, 230, '2026-07-06T14:00', '2026-07-06T17:50', 'https://www.flixbus.de/bus/berlin-prague'),
];

// Also a 4th itinerary for richness: train + flight via Vienna stopover (Vienne)
const viennaStopover: Stopover = {
  city: vienna,
  days: 1,
  note: 'Découvrez le centre historique et le château de Schönbrunn. Auberges dès 30€/nuit.',
  estimatedLodgingCost: 35,
  currency: 'EUR',
};

const viennaStopoverSegments: Segment[] = [
  seg('s4-1', nantes, paris, 'train', 'TGV inOui', 35, 125, `${DEP}06:15`, `${DEP}08:20`, 'https://www.trainline.fr/search/nantes-paris'),
  seg('s4-2', paris, vienna, 'flight', 'Austrian Airlines', 89, 130, `${DEP}11:00`, `${DEP}13:10`, 'https://www.aviasales.com/routes/CDG/VIE'),
  // 1-day stopover in Vienna
  seg('s4-3', vienna, prague, 'train', 'ÖBB Railjet', 29, 240, '2026-07-05T16:00', '2026-07-05T20:00', 'https://www.trainline.fr/search/vienna-prague'),
];

const transportOnlyDuration = (segs: Segment[]) => segs.reduce((a, s) => a + s.durationMinutes, 0);

export const MOCK_ITINERARIES: Itinerary[] = [
  {
    id: 'itin-fastest',
    type: 'fastest',
    segments: fastestSegments,
    totalPrice: fastestSegments.reduce((a, s) => a + s.price, 0),
    totalDurationMinutes: transportOnlyDuration(fastestSegments) + 130, // includes ~2h10 layover
    currency: 'EUR',
    savingsPercent: 0,
    tags: ['Trajet le plus court', 'Train + Vol'],
  },
  {
    id: 'itin-cheapest',
    type: 'cheapest',
    segments: cheapestSegments,
    totalPrice: cheapestSegments.reduce((a, s) => a + s.price, 0),
    totalDurationMinutes: transportOnlyDuration(cheapestSegments) + 170,
    currency: 'EUR',
    savingsPercent: 37,
    tags: ['Multimodal', 'Bus + Vol + Bus', 'Petit budget'],
  },
  {
    id: 'itin-smart-berlin',
    type: 'smart_stopover',
    segments: smartStopoverSegments,
    stopover: stopoverBerlin,
    totalPrice: smartStopoverSegments.reduce((a, s) => a + s.price, 0) + stopoverBerlin.estimatedLodgingCost,
    totalDurationMinutes: transportOnlyDuration(smartStopoverSegments) + 2 * 24 * 60, // +2 days stopover
    currency: 'EUR',
    savingsPercent: 42,
    tags: ['Pépite Éscale', '2 jours à Berlin', 'Voyage + Tourisme'],
  },
  {
    id: 'itin-smart-vienna',
    type: 'smart_stopover',
    segments: viennaStopoverSegments,
    stopover: viennaStopover,
    totalPrice: viennaStopoverSegments.reduce((a, s) => a + s.price, 0) + viennaStopover.estimatedLodgingCost,
    totalDurationMinutes: transportOnlyDuration(viennaStopoverSegments) + 1 * 24 * 60,
    currency: 'EUR',
    savingsPercent: 31,
    tags: ['Pépite Éscale', '1 jour à Vienne', 'Train + Vol + Train'],
  },
];
