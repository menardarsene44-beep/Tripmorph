import { useState, useCallback } from 'react';
import { Compass, Plane, TrainFront, Bus, Sparkles, Route, Globe2, Bot, LayoutDashboard } from 'lucide-react';
import SearchBar from '@/components/SearchBar';
import Results from '@/components/Results';
import ChatPanel from '@/components/ChatPanel';
import { City, Itinerary, TravelMode } from '@/types';
import { searchItineraries, getApiStatus } from '@/services/api';

export default function App() {
  const [itineraries, setItineraries] = useState<Itinerary[]>([]);
  const [loading, setLoading] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);
  const [searchMeta, setSearchMeta] = useState<{ from: string; to: string } | null>(null);
  const [highlightId, setHighlightId] = useState<string | undefined>(undefined);
  const apiStatus = getApiStatus();

  const handleSearch = useCallback(
    async (params: {
      fromCity: City;
      toCity: City;
      departDate: string;
      returnDate: string;
      oneWay: boolean;
      travelMode: TravelMode;
      allowStopovers: boolean;
    }) => {
      setLoading(true);
      setHasSearched(true);
      setSearchMeta({ from: params.fromCity.name, to: params.toCity.name });
      const results = await searchItineraries(params);
      setItineraries(results);
      setLoading(false);
    },
    [],
  );

  const handleItinerariesUpdate = useCallback((updated: Itinerary[]) => {
    setItineraries(updated);
  }, []);

  const handleHighlight = useCallback((id: string | undefined) => {
    setHighlightId(id);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 via-white to-slate-50">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-white/80 backdrop-blur-md border-b border-slate-100">
        <div className="max-w-[1600px] mx-auto px-4 sm:px-6 py-3.5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-sky-500 to-blue-600 flex items-center justify-center shadow-md shadow-sky-500/30">
              <Compass className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="text-base font-extrabold tracking-tight text-slate-800 leading-none">TripMorph</div>
              <div className="text-[10px] text-slate-400 font-medium leading-none mt-0.5">Comparateur multimodal intelligent</div>
            </div>
          </div>
          <div className="hidden md:flex items-center gap-4 text-xs">
            <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-100 text-slate-500 font-medium">
              <Globe2 className="w-3.5 h-3.5" />
              {apiStatus.flights ? 'API live' : 'Mode démo'}
            </span>
          </div>
        </div>
      </header>

      {/* Hero (only before first search) */}
      {!hasSearched && (
        <section className="relative overflow-hidden">
          <div className="absolute inset-0 -z-10">
            <div className="absolute top-0 left-1/4 w-72 h-72 bg-sky-200/30 rounded-full blur-3xl" />
            <div className="absolute top-20 right-1/4 w-72 h-72 bg-violet-200/20 rounded-full blur-3xl" />
          </div>
          <div className="max-w-5xl mx-auto px-4 sm:px-6 pt-10 sm:pt-16 pb-6 text-center">
            <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-sky-100 text-sky-700 text-xs font-bold mb-4">
              <Sparkles className="w-3.5 h-3.5" />
              Vol · Train · Bus — comparé en un seul coup d'œil
            </div>
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-slate-800 leading-[1.1]">
              Voyagez plus malin,<br />
              <span className="bg-gradient-to-r from-sky-500 to-blue-600 bg-clip-text text-transparent">pas plus cher</span>
            </h1>
            <p className="mt-4 text-sm sm:text-base text-slate-500 max-w-2xl mx-auto leading-relaxed">
              Comparez vols, trains et bus en temps réel. Discutez avec notre IA pour affiner votre recherche
              et découvrez des escales touristiques qui réduisent le coût global de votre voyage.
            </p>
            <div className="flex items-center justify-center gap-6 mt-5">
              {[
                { Icon: Plane, label: 'Avion', color: 'text-sky-500' },
                { Icon: TrainFront, label: 'Train', color: 'text-emerald-500' },
                { Icon: Bus, label: 'Bus', color: 'text-amber-500' },
              ].map(({ Icon, label, color }) => (
                <div key={label} className="flex items-center gap-1.5 text-sm font-bold text-slate-400">
                  <Icon className={`w-5 h-5 ${color}`} />
                  {label}
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Search bar (always visible) */}
      <section className="max-w-[1600px] mx-auto px-4 sm:px-6 mt-4">
        <SearchBar onSearch={handleSearch} loading={loading} />
      </section>

      {/* Split-screen: Chat (35%) + Dashboard (65%) */}
      {hasSearched ? (
        <main className="max-w-[1600px] mx-auto px-4 sm:px-6 mt-6 pb-12">
          {searchMeta && (
            <div className="mb-4 flex items-center gap-2 text-sm text-slate-500">
              <Route className="w-4 h-4 text-sky-500" />
              <span className="font-semibold text-slate-700">{searchMeta.from}</span>
              <span className="text-slate-300">→</span>
              <span className="font-semibold text-slate-700">{searchMeta.to}</span>
              <span className="text-slate-400">· {itineraries.length} itinéraire{itineraries.length > 1 ? 's' : ''} trouvé{itineraries.length > 1 ? 's' : ''}</span>
            </div>
          )}

          <div className="flex flex-col lg:flex-row gap-5">
            {/* Left: Chat (35%) */}
            <div className="w-full lg:w-[35%] lg:shrink-0">
              <div className="lg:sticky lg:top-24 h-[420px] lg:h-[calc(100vh-7rem)]">
                <ChatPanel
                  itineraries={itineraries}
                  onItinerariesUpdate={handleItinerariesUpdate}
                  onHighlight={handleHighlight}
                />
              </div>
            </div>

            {/* Right: Dashboard (65%) */}
            <div className="w-full lg:flex-1">
              <div className="flex items-center gap-2 mb-3 lg:hidden">
                <LayoutDashboard className="w-4 h-4 text-slate-400" />
                <span className="text-sm font-bold text-slate-500">Tableau de bord</span>
              </div>
              <Results
                itineraries={itineraries}
                loading={loading}
                highlightId={highlightId}
              />
            </div>
          </div>
        </main>
      ) : (
        <main className="max-w-[1600px] mx-auto px-4 sm:px-6 mt-8 pb-12">
          <HowItWorks />
        </main>
      )}

      {/* Footer */}
      <footer className="border-t border-slate-100 bg-white">
        <div className="max-w-[1600px] mx-auto px-4 sm:px-6 py-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-sm text-slate-400">
            <Compass className="w-4 h-4 text-sky-500" />
            <span className="font-bold text-slate-600">TripMorph</span>
            <span>— le comparateur multimodal qui transforme vos escales en aventures.</span>
          </div>
          <div className="text-xs text-slate-400">
            Données de démonstration · Connectez vos clés API dans <code className="px-1 py-0.5 rounded bg-slate-100 text-slate-500 font-mono">.env</code> pour les prix en temps réel
          </div>
        </div>
      </footer>
    </div>
  );
}

function HowItWorks() {
  const steps = [
    { icon: Compass, title: '1. Recherchez', desc: 'Saisissez votre départ, votre arrivée et vos dates. Choisissez votre priorité : rapidité, budget ou compromis.', color: 'from-sky-500 to-blue-600' },
    { icon: Bot, title: '2. Discutez avec l\'IA', desc: 'L\'assistant à gauche affine votre recherche en langage naturel : « Enlève les low-cost », « Ajoute un jour à Berlin »…', color: 'from-violet-500 to-purple-600' },
    { icon: Sparkles, title: '3. Découvrez les pépites', desc: 'L\'IA suggère des villes étapes où passer 1 à 3 jours peut réduire le coût total du voyage.', color: 'from-emerald-500 to-teal-600' },
  ];
  return (
    <section id="how" className="mt-8">
      <h2 className="text-2xl font-extrabold text-center text-slate-800 mb-2">Comment ça marche ?</h2>
      <p className="text-center text-slate-400 mb-8 max-w-xl mx-auto">Recherchez, discutez avec l'IA, et laissez-la affiner vos itinéraires en temps réel.</p>
      <div className="grid sm:grid-cols-3 gap-5">
        {steps.map((s) => {
          const Icon = s.icon;
          return (
            <div key={s.title} className="group relative bg-white rounded-2xl border border-slate-100 p-6 hover:shadow-lg hover:shadow-slate-200/40 transition-all hover:-translate-y-1">
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${s.color} flex items-center justify-center shadow-lg mb-4`}>
                <Icon className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-lg font-bold text-slate-800 mb-1.5">{s.title}</h3>
              <p className="text-sm text-slate-500 leading-relaxed">{s.desc}</p>
            </div>
          );
        })}
      </div>
    </section>
  );
}
