/**
 * Modular API service layer.
 *
 * Flight search is proxied through a Supabase Edge Function (flight-search)
 * that calls the Aviasales / Travelpayouts API server-side, keeping the
 * API token off the client. The affiliate marker is injected into every
 * booking link both in the edge function and in the mock ground-transport
 * links.
 *
 * .env variables used client-side:
 *   VITE_TRAVELPAYOUTS_MARKER  – Affiliate marker id (visible in links)
 *   VITE_SUPABASE_URL          – Pre-populated
 *   VITE_SUPABASE_ANON_KEY     – Pre-populated
 *
 * Server-side (edge function, stored in Supabase vault):
 *   TRAVELPAYOUTS_API_KEYS     – Aviasales API token
 */

import { City, Itinerary, Segment, TravelMode } from '@/types';
import { MOCK_ITINERARIES } from '@/data/mockItineraries';
import { CITIES } from '@/data/cities';

const ENV = import.meta.env;
const TRAVELPAYOUTS_MARKER = ENV.VITE_TRAVELPAYOUTS_MARKER || '677777';

export interface SearchParams {
  fromCity: City;
  toCity: City;
  departDate: string;
  returnDate?: string;
  oneWay: boolean;
  travelMode: TravelMode;
  allowStopovers: boolean;
}

// ─── Helpers ────────────────────────────────────────────────

function isConfigured(key: string): boolean {
  const v = ENV[key];
  return typeof v === 'string' && v.length > 0 && !v.includes('your_');
}

export function getApiStatus(): { flights: boolean; ground: boolean; ai: boolean } {
  return {
    flights: true,
    ground: isConfigured('VITE_TRAVELPAYOUTS_MARKER'),
    ai: isConfigured('VITE_OPENAI_API_KEY'),
  };
}

function buildAffiliateUrl(base: string): string {
  const sep = base.includes('?') ? '&' : '?';
  return `${base}${sep}marker=${TRAVELPAYOUTS_MARKER}`;
}

// ─── Airline IATA code → name mapping ───────────────────────

const AIRLINE_NAMES: Record<string, string> = {
  AF: 'Air France',
  BA: 'British Airways',
  LH: 'Lufthansa',
  KL: 'KLM',
  EZ: 'easyJet',
  U2: 'easyJet',
  TO: 'Transavia',
  VY: 'Vueling',
  FR: 'Ryanair',
  W6: 'Wizz Air',
  OS: 'Austrian Airlines',
  OK: 'Czech Airlines',
  LO: 'LOT Polish Airlines',
  IB: 'Iberia',
  AZ: 'ITA Airways',
  SK: 'SAS',
  AY: 'Finnair',
  EI: 'Aer Lingus',
  EW: 'Eurowings',
  DP: 'Pobeda',
  SU: 'Aeroflot',
  TK: 'Turkish Airlines',
  ET: 'Ethiopian Airlines',
  EK: 'Emirates',
  QR: 'Qatar Airways',
  AT: 'Royal Air Maroc',
  TN: 'Air Tahiti Nui',
  AZI: 'Air France',
};

function airlineName(code: string): string {
  return AIRLINE_NAMES[code.toUpperCase()] || code.toUpperCase();
}

// ─── Flight search via edge function ────────────────────────

export interface FlightOffer {
  price: number;
  airline: string;
  flightNumber: number;
  departureAt: string;
  returnAt?: string;
  transfers: number;
  bookingUrl: string;
}

export async function searchFlights(
  from: City,
  to: City,
  departDate: string,
  returnDate?: string,
): Promise<FlightOffer[]> {
  if (!from.iata || !to.iata) return [];

  const supabaseUrl = ENV.VITE_SUPABASE_URL;
  const anonKey = ENV.VITE_SUPABASE_ANON_KEY;
  if (!supabaseUrl || !anonKey) return [];

  try {
    const res = await fetch(`${supabaseUrl}/functions/v1/flight-search`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${anonKey}`,
        apikey: anonKey,
      },
      body: JSON.stringify({
        origin: from.iata,
        destination: to.iata,
        departDate: departDate?.slice(0, 7) || undefined, // API wants yyyy-mm
        returnDate: returnDate?.slice(0, 7) || undefined,
        currency: 'eur',
        marker: TRAVELPAYOUTS_MARKER,
      }),
    });

    if (!res.ok) return [];

    const data = await res.json();
    if (data.success && Array.isArray(data.offers)) {
      return data.offers as FlightOffer[];
    }
    return [];
  } catch {
    return [];
  }
}

// ─── Ground transport (FlixBus / Trainline) ─────────────────
// Ground-transport API integration is still mock — real endpoints
// require separate FlixBus/Trainline API access.

export async function searchGround(_from: City, _to: City, _date: string): Promise<Segment[]> {
  return [];
}

// ─── AI stopover suggestions (OpenAI GPT-4o) ────────────────

export async function suggestStopovers(from: City, to: City): Promise<string[]> {
  if (!isConfigured('VITE_OPENAI_API_KEY')) return [];

  const prompt = `Tu es un expert voyage. Entre "${from.name}" et "${to.name}", propose 3 villes étapes (hubs pivots) logiques qui pourraient réduire le coût global du voyage tout en offrant un intérêt touristique. Réponds uniquement avec les noms de villes séparés par des virgules.`;

  try {
    const res = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${ENV.VITE_OPENAI_API_KEY}`,
      },
      body: JSON.stringify({
        model: 'gpt-4o',
        messages: [{ role: 'user', content: prompt }],
        max_tokens: 120,
        temperature: 0.7,
      }),
    });
    if (!res.ok) return [];
    const data = await res.json();
    const text: string = data.choices?.[0]?.message?.content ?? '';
    return text.split(',').map((s) => s.trim()).filter(Boolean).slice(0, 3);
  } catch {
    return [];
  }
}

// ─── Orchestrator: assemble full itineraries ────────────────

export async function searchItineraries(params: SearchParams): Promise<Itinerary[]> {
  await new Promise((r) => setTimeout(r, 400));

  // Start with mock itineraries
  let results = [...MOCK_ITINERARIES];

  // ─── Try to fetch live flight prices and merge ────────────
  const liveFlights = await searchFlights(
    params.fromCity,
    params.toCity,
    params.departDate,
    params.oneWay ? undefined : params.returnDate,
  );

  if (liveFlights.length > 0) {
    results = mergeLiveFlights(results, liveFlights, params.fromCity, params.toCity);
  }

  // ─── Also try stopover city pairs (e.g. Nantes→Berlin, Berlin→Prague) ──
  if (params.allowStopovers) {
    const stopoverResults = await fetchStopoverFlights(params.fromCity, params.toCity, params.departDate);
    results = [...results, ...stopoverResults];
  }

  // Filter
  if (!params.allowStopovers) {
    results = results.filter((i) => i.type !== 'smart_stopover');
  }

  // Deduplicate by id (keep first occurrence)
  const seen = new Set<string>();
  results = results.filter((it) => {
    if (seen.has(it.id)) return false;
    seen.add(it.id);
    return true;
  });

  // Sort by travel mode preference
  if (params.travelMode === 'ultra_fast') {
    results.sort((a, b) => a.totalDurationMinutes - b.totalDurationMinutes);
  } else if (params.travelMode === 'ultra_eco') {
    results.sort((a, b) => a.totalPrice - b.totalPrice);
  } else {
    results.sort((a, b) =>
      a.totalPrice / 100 + a.totalDurationMinutes / 600 - (b.totalPrice / 100 + b.totalDurationMinutes / 600),
    );
  }

  return results;
}

// ─── Merge live flight data into existing itineraries ───────

function mergeLiveFlights(
  itineraries: Itinerary[],
  flights: FlightOffer[],
  from: City,
  to: City,
): Itinerary[] {
  // Find the cheapest live flight for the direct route
  const cheapest = flights[0];
  if (!cheapest) return itineraries;

  // Create or update a direct-flight itinerary
  const liveSegment: Segment = {
    id: 'live-direct-flight',
    fromCity: from,
    toCity: to,
    mode: 'flight',
    carrier: airlineName(cheapest.airline),
    price: cheapest.price,
    currency: 'EUR',
    durationMinutes: cheapest.transfers === 0 ? 140 : 140 + cheapest.transfers * 90,
    departureTime: cheapest.departureAt,
    arrivalTime: estimateArrival(cheapest.departureAt, cheapest.transfers === 0 ? 140 : 140 + cheapest.transfers * 90),
    bookingUrl: cheapest.bookingUrl,
    deepLink: cheapest.bookingUrl,
  };

  // Build a direct-flight itinerary (type: fastest)
  const directItinerary: Itinerary = {
    id: 'itin-live-direct',
    type: 'fastest',
    segments: [liveSegment],
    totalPrice: cheapest.price,
    totalDurationMinutes: liveSegment.durationMinutes,
    currency: 'EUR',
    savingsPercent: 0,
    tags: ['Vol direct', airlineName(cheapest.airline), `${cheapest.transfers} escale${cheapest.transfers > 1 ? 's' : ''}`.replace('0 escales', 'Sans escale')],
  };

  // If there are multi-stop cheap flights, create a "cheapest live" itinerary
  const withStops = flights.filter((f) => f.transfers > 0);
  let cheapestLiveItin: Itinerary | null = null;

  if (withStops.length > 0) {
    const cheapestWithStops = withStops[0];
    const stopSegment: Segment = {
      id: 'live-cheap-flight',
      fromCity: from,
      toCity: to,
      mode: 'flight',
      carrier: airlineName(cheapestWithStops.airline),
      price: cheapestWithStops.price,
      currency: 'EUR',
      durationMinutes: 140 + cheapestWithStops.transfers * 90,
      departureTime: cheapestWithStops.departureAt,
      arrivalTime: estimateArrival(cheapestWithStops.departureAt, 140 + cheapestWithStops.transfers * 90),
      bookingUrl: cheapestWithStops.bookingUrl,
      deepLink: cheapestWithStops.bookingUrl,
    };
    cheapestLiveItin = {
      id: 'itin-live-cheap',
      type: 'cheapest',
      segments: [stopSegment],
      totalPrice: cheapestWithStops.price,
      totalDurationMinutes: stopSegment.durationMinutes,
      currency: 'EUR',
      savingsPercent: 0,
      tags: ['Vol avec escale', airlineName(cheapestWithStops.airline), 'Prix en temps réel'],
    };
  }

  // Replace mock fastest with live direct if cheaper or similar
  const updated = itineraries.filter((it) => it.id !== 'itin-fastest');
  const result = [directItinerary, ...updated];
  if (cheapestLiveItin) {
    // Insert if cheaper than existing cheapest
    const mockCheapest = updated.find((it) => it.type === 'cheapest');
    if (!mockCheapest || cheapestLiveItin.totalPrice < mockCheapest.totalPrice) {
      result.push(cheapestLiveItin);
    }
  }

  // Recalculate savings percentages relative to the most expensive option
  recalcSavings(result);

  return result;
}

// ─── Fetch flights for stopover routes ──────────────────────

async function fetchStopoverFlights(from: City, to: City, departDate: string): Promise<Itinerary[]> {
  // Try common stopover cities between origin and destination
  const stopoverCityIds = ['berlin', 'paris', 'vienna', 'amsterdam', 'munich'];
  const itineraries: Itinerary[] = [];

  for (const cityId of stopoverCityIds) {
    const stopCity = CITIES.find((c) => c.id === cityId);
    if (!stopCity || stopCity.id === from.id || stopCity.id === to.id) continue;
    if (!stopCity.iata) continue;

    // Fetch both legs in parallel
    const [leg1Flights, leg2Flights] = await Promise.all([
      searchFlights(from, stopCity, departDate),
      searchFlights(stopCity, to, departDate),
    ]);

    if (leg1Flights.length === 0 || leg2Flights.length === 0) continue;

    const leg1 = leg1Flights[0];
    const leg2 = leg2Flights[0];
    const totalPrice = leg1.price + leg2.price;

    // Create segments with the live data
    const seg1: Segment = {
      id: `live-so-1-${cityId}`,
      fromCity: from,
      toCity: stopCity,
      mode: 'flight',
      carrier: airlineName(leg1.airline),
      price: leg1.price,
      currency: 'EUR',
      durationMinutes: leg1.transfers === 0 ? 150 : 150 + leg1.transfers * 90,
      departureTime: leg1.departureAt,
      arrivalTime: estimateArrival(leg1.departureAt, leg1.transfers === 0 ? 150 : 150 + leg1.transfers * 90),
      bookingUrl: leg1.bookingUrl,
      deepLink: leg1.bookingUrl,
    };

    const seg2: Segment = {
      id: `live-so-2-${cityId}`,
      fromCity: stopCity,
      toCity: to,
      mode: 'flight',
      carrier: airlineName(leg2.airline),
      price: leg2.price,
      currency: 'EUR',
      durationMinutes: leg2.transfers === 0 ? 120 : 120 + leg2.transfers * 90,
      departureTime: leg2.departureAt,
      arrivalTime: estimateArrival(leg2.departureAt, leg2.transfers === 0 ? 120 : 120 + leg2.transfers * 90),
      bookingUrl: leg2.bookingUrl,
      deepLink: leg2.bookingUrl,
    };

    itineraries.push({
      id: `itin-live-so-${cityId}`,
      type: 'smart_stopover',
      segments: [seg1, seg2],
      stopover: {
        city: stopCity,
        days: 2,
        note: `Escale économique à ${stopCity.name}. Découvrez la ville tout en réduisant le coût de votre voyage.`,
        estimatedLodgingCost: 50,
        currency: 'EUR',
      },
      totalPrice: totalPrice + 50,
      totalDurationMinutes: seg1.durationMinutes + seg2.durationMinutes + 2 * 24 * 60,
      currency: 'EUR',
      savingsPercent: 0,
      tags: ['Pépite Éscale (live)', `2 jours à ${stopCity.name}`, 'Vols en temps réel'],
    });
  }

  if (itineraries.length > 0) {
    // Remove mock smart_stopover if we have live ones
    recalcSavings(itineraries);
  }

  return itineraries;
}

// ─── Utilities ──────────────────────────────────────────────

function estimateArrival(departureIso: string, durationMin: number): string {
  const dep = new Date(departureIso);
  dep.setMinutes(dep.getMinutes() + durationMin);
  return dep.toISOString();
}

function recalcSavings(itineraries: Itinerary[]): void {
  if (itineraries.length === 0) return;
  const maxPrice = Math.max(...itineraries.map((i) => i.totalPrice));
  for (const it of itineraries) {
    if (maxPrice > 0 && it.totalPrice < maxPrice) {
      it.savingsPercent = Math.round(((maxPrice - it.totalPrice) / maxPrice) * 100);
    }
  }
}
