Deno.serve(async (req: Request) => {
  const corsHeaders = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
  };

  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const { origin, destination, departDate, returnDate, currency, marker } = await req.json();

    if (!origin || !destination) {
      return new Response(
        JSON.stringify({ error: "origin and destination are required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    // ─── Get API token from Deno env first, then vault ─────────
    let token = Deno.env.get("TRAVELPAYOUTS_API_KEYS");

    if (!token) {
      // Fallback: read from Supabase vault
      const supabaseUrl = Deno.env.get("SUPABASE_URL");
      const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
      if (supabaseUrl && serviceRoleKey) {
        const vaultRes = await fetch(
          `${supabaseUrl}/rest/v1/vault/secrets?name=eq.TRAVELPAYOUTS_API_KEYS&select=decrypted_secret`,
          {
            headers: {
              apikey: serviceRoleKey,
              Authorization: `Bearer ${serviceRoleKey}`,
            },
          },
        );
        if (vaultRes.ok) {
          const vaultData = await vaultRes.json();
          if (Array.isArray(vaultData) && vaultData.length > 0) {
            token = vaultData[0].decrypted_secret;
          }
        }
      }
    }

    if (!token) {
      return new Response(
        JSON.stringify({ error: "Travelpayouts API token not configured" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    const cur = currency || "eur";
    const affMarker = marker || "";

    // ─── 1. Cheap tickets (with stops, best price) ──────────────
    const cheapParams = new URLSearchParams({
      origin,
      destination,
      currency: cur,
      token,
    });
    if (departDate) cheapParams.set("depart_date", departDate);
    if (returnDate) cheapParams.set("return_date", returnDate);

    const cheapUrl = `https://api.travelpayouts.com/v1/prices/cheap?${cheapParams.toString()}`;
    const cheapRes = await fetch(cheapUrl, {
      headers: { "x-access-token": token },
    });

    let cheapData: Record<string, Record<string, {
      price: number;
      airline: string;
      flight_number: number;
      departure_at: string;
      return_at?: string;
      expires_at: string;
    }>> = {};

    if (cheapRes.ok) {
      const json = await cheapRes.json();
      if (json.success && json.data) cheapData = json.data;
    }

    // ─── 2. Direct (non-stop) tickets ───────────────────────────
    const directParams = new URLSearchParams({
      origin,
      destination,
      currency: cur,
      token,
    });
    if (departDate) directParams.set("depart_date", departDate);
    if (returnDate) directParams.set("return_date", returnDate);

    const directUrl = `https://api.travelpayouts.com/v1/prices/direct?${directParams.toString()}`;
    const directRes = await fetch(directUrl, {
      headers: { "x-access-token": token },
    });

    let directData: Record<string, Record<string, {
      price: number;
      airline: string;
      flight_number: number;
      departure_at: string;
      return_at?: string;
      expires_at: string;
    }>> = {};

    if (directRes.ok) {
      const json = await directRes.json();
      if (json.success && json.data) directData = json.data;
    }

    // ─── 3. Merge & normalize results ───────────────────────────
    interface FlightOffer {
      price: number;
      airline: string;
      flightNumber: number;
      departureAt: string;
      returnAt?: string;
      transfers: number;
      bookingUrl: string;
    }

    const offers: FlightOffer[] = [];

    for (const [destCode, flights] of Object.entries(cheapData)) {
      for (const [key, flight] of Object.entries(flights)) {
        const transferCount = parseInt(key, 10) || 0;
        offers.push({
          price: flight.price,
          airline: flight.airline,
          flightNumber: flight.flight_number,
          departureAt: flight.departure_at,
          returnAt: flight.return_at,
          transfers: transferCount,
          bookingUrl: `https://www.aviasales.com/routes/${origin}/${destCode}` +
            (affMarker ? `?marker=${affMarker}` : ""),
        });
      }
    }

    const seenKeys = new Set(offers.map((o) => `${o.airline}-${o.flightNumber}-${o.departureAt}`));
    for (const [destCode, flights] of Object.entries(directData)) {
      for (const [, flight] of Object.entries(flights)) {
        const dedupKey = `${flight.airline}-${flight.flight_number}-${flight.departure_at}`;
        if (seenKeys.has(dedupKey)) continue;
        seenKeys.add(dedupKey);
        offers.push({
          price: flight.price,
          airline: flight.airline,
          flightNumber: flight.flight_number,
          departureAt: flight.departure_at,
          returnAt: flight.return_at,
          transfers: 0,
          bookingUrl: `https://www.aviasales.com/routes/${origin}/${destCode}` +
            (affMarker ? `?marker=${affMarker}` : ""),
        });
      }
    }

    offers.sort((a, b) => a.price - b.price);

    return new Response(
      JSON.stringify({ success: true, offers: offers.slice(0, 10), currency: cur }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
